var jose = {
    nombre: 'Jose',
    apellido: 'Gutierrez',
    edad: '16',
    ingeniero: true,
    cocinero: false,
    cantante: false,
    dj: false,
    guitarrista: true,
    drone: true

}

x = 18;

function imprimirOficio(persona) {
    console.log(`${persona.nombre} es:`);

    if (persona.ingeniero === true){
        console.log('Si es Ingeniero');

    }
    else{
        console.log('No es Ingeniero')
    }    

    //

    if (persona.cocinero === true){
        console.log('Si es Cocinero');

    }
    else{
        console.log('No es Cocinero')
    }

    //
    
    if (persona.cantante === true){
        console.log('Si es Cantante');

    }
    else{
        console.log('No es Cantante')
    }

    //
    
    if (persona.dj === true){
        console.log('Si es Dj');

    }
    else{
        console.log('No es DJ')
    } 
    
    //

    if (persona.guitarrista === true){
        console.log('Si es Guitarrista');

    }
    else{
        console.log('No es Guitarrista')
    }  

    //
    
    if (persona.drone === true){
        console.log('Si vuela drones');

    }
    else{
        console.log('No vuela drones')
    } 
}

function imprimirEdad(persona) {
    console.log(`Jose tiene ${persona.edad}`);

    if (persona.edad >= x){
        console.log('Es mayor de edad.');
    }
    else{
        console.log('Es menor de edad');
    }
    
}

imprimirOficio(jose);
imprimirEdad(jose);