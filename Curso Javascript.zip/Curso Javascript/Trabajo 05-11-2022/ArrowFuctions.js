var persona = {
    nombre: 'Jose',
    apellido: 'Gutierrez',
    edad: '17  ',
    ingeniero: true,
    cocinero: false,
    cantante: false,
    dj: false,
    guitarrista: true,
    drone: true

}

const MAYORIA_DE_EDAD = 17;

//function esMayordeEdad(persona) {
//return persona.edad > MAYORIA_DE_EDAD;
//}

//funcion anonima
//const esMayordeEdad = function (persona) {
//    return persona.edad > MAYORIA_DE_EDAD;
    
//}

//funcion Arrow
const esMayordeEdad = persona => persona.edad > MAYORIA_DE_EDAD;

// const esMayordeEdad2 = ({ edad }) => edad > MAYORIA_DE_EDAD;


function imprimirSiesMayordeEdad(persona) {
    if (esMayordeEdad(persona)){
    console.log(`${persona.nombre} es mayor de edad`);
    } else {
    console.log(`${persona.nombre} es menor de edad`);
   }
  }


//crear una funcion que nos de acceso segun nuestra edad

function permitiracceso(){
  if (!esMayordeEdad(persona)) {
    console.log(`Acceso Denegado`);
  }else{
    console.log(`Acceso Permitido`);
}
}

//elaborar una funcion flecha
const permitirAcceso = persona => persona.edad > MAYORIA_DE_EDAD;