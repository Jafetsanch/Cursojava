var persona = {
    nombre: 'Jose',
    apellido: 'Gutierrez',
    edad: '19',
    ingeniero: true,
    cocinero: false,
    cantante: false,
    dj: false,
    guitarrista: true,
    drone: true

}

const MAYORIA_DE_EDAD = 17;

function esMayordeEdad(persona) {
return persona.edad > MAYORIA_DE_EDAD;
}

function imprimirSiesMayordeEdad(persona) {
    if (esMayordeEdad(persona)){
    console.log(`${persona.nombre} es mayor de edad`);
    } else {
    console.log(`${persona.nombre} es menor de edad`);
   }
  }


