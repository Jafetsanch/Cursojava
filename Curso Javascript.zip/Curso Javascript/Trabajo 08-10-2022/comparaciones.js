var x = 4, y = '4';

// = Asignacio
// == Comparacion de valores
// === Comparacion de valores y de tipo de datos

var sacha = {
    nombre: 'Sacha'

}

//var otrapersona = {
// nombre: 'Sacha'
//}

//var otrapersona = {
  // ...sacha

//}

var otrapersona = sacha