var jose = {
    nombre: 'Jose',
    apellido: 'Gutierrez',
    edad: 16
}

var jafet = {
    nombre: 'Jafet',
    apellido: 'vega',
    edad: 15
}

function imprimirNombreEnMayusculas(persona){
    var nombre = persona.nombre;
    console.log(nombre.toUpperCase());
}

imprimirNombreEnMayusculas(jose);
imprimirNombreEnMayusculas(jafet);

function birthday(persona) {
    persona.edad = persona.edad + 1
    
}

function cumpleaños(persona) {
    return{
        ...persona,
        edad: persona.edad + 1

    }
}