for (x = 0, y = 5; x < 5; x++, y--) {
    console.log("Valor de x y y:", x, y);
  }