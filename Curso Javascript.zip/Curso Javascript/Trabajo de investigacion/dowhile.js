var resultado = '';
x = 0;

do {
  x = x + 1;
  resultado = resultado + x;
} while (x < 5);

console.log(resultado); 