x = 10; 

while (x < 16) {
  console.log("Valor de x:", x);

  x = x + 1;
} 