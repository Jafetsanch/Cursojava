var Animal = 'Medico';
switch (Animal) {
  case 'Chef':
  case 'Musico':
  case 'Medico':
  case 'Ingeniero':
    console.log('Jose trabajo de esto.');
    break;
  case 'DJ':
  case 'Guitarrista':
  default:
    console.log('Jose no trabaja en esto.');
} 