var jose = {
    nombre: 'Jose',
    apellido: 'Gutierrez',
    edad: '17  ',
    peso: '75 Kg '
}

console.log(`Al comenzar el año ${jose.nombre} ${jose.apellido} pesaba: ${jose.peso}`);

const INCREMENTO_PESO = 0.20;


const pesoAleatorio = (min, max) => {
    return ((Math.random(0.20) * (max - min)) + min + INCREMENTO_PESO).toFixed(2); 

};
    for (let x = 0; x < 1; x++){
        
        console.log(`Al finalizar el año ${jose.nombre} ${jose.apellido} termino pesando: ${pesoAleatorio(50, 90)} Kg`);
    }
