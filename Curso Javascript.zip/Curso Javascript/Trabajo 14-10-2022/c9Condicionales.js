var sacha = {
    nombre: 'Sacha',
    apellido: "Smith",
    edad: 28,
    ingeniero: true,
    cocinero: true,
    cantante: true,
    dj: true,
    guitarrista: true,
    drone: true
}

function imprimirProfesiones(persona) {
    console.log(`${persona.nombre} no es: `);
//        (persona.ingeniero)
    if (persona.ingeniero === true) {
        console.log('Ingeniero')
    }
    console.log(`${persona.nombre} es: `);
    //        (persona.cocinero)
        if (persona.cocinero === true) {
            console.log('Cocinero')
        }
        console.log(`${persona.nombre} no es: `);
        //        (persona.cantante)
            if (persona.cantante === true) {
                console.log('Cantante')
            }
            console.log(`${persona.nombre} es: `);
            //        (persona.dj)
                if (persona.dj === true) {
                    console.log('Dj')
                }
                console.log(`${persona.nombre} no es: `);
                //        (persona.guitarrista)
                    if (persona.guitarrista === true) {
                        console.log('Guitarriasta')
                    }
                    console.log(`${persona.nombre} es: `);
                    //        (persona.drone)
                        if (persona.drone === true) {
                            console.log('Drone')
                        }
}
    function imprimirMayorMenor(persona){
        if(persona.edad >= 18)

        console.log ("Sacha es Mayor de Edad")

        else if (persona.edad < 18)

        console.log("Sacha es Menor de Edad")

    }
imprimirMayorMenor(sacha);
imprimirProfesiones(sacha);

// Reto#1 Mostrar todas las profesiones de sacha (que sean true)

// Reto#2 Mostrar que sacha no tiene dicha profesion: No es dj

// Reto#3 Crear una funcion para saber si la persona es mayor de edad

// Ejemplo de salida: Sacha es mayor de edad | sacha no es mayor de edad