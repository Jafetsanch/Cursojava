var primerpersona = {  // Variable la cual  imprime el nombre, apellido y edad de la primera persona
    nombre: 'Jose',
    apellido: 'Gutierrez',
    edad: 16
}

var segundapersona = {  // Variable la cual  imprime el nombre, apellido y edad de la segunda persona
    nombre: 'Jafet',
    apellido: 'Vega',
    edad: 17
}

function imprimirNombreEnMayusculas(persona){  // La funcion imprimira el nombre de la persona en la comnsola
    var nombre = persona.nombre;
    console.log(nombre.toUpperCase());
}

imprimirNombreEnMayusculas(primerpersona);  // Esto basicamente imprime la variable primera persona en letras mayusculas
imprimirNombreEnMayusculas(segundapersona);  // Esto basicamente imprime la variable segunda persona en letras mayusculas

function imprimirElnombreYedad(persona1) { // Imprime el nombre y la edad de la primera persona

    var {nombre, edad, apellido} = persona1 // La variables variables corresponden a la persona1 
	console.log(`Hola soy ${nombre} ${apellido} y tengo ${edad} años`);  // Esto es lo que se muestra en la consola
}

imprimirElnombreYedad(primerpersona);
imprimirElnombreYedad(segundapersona)
    
