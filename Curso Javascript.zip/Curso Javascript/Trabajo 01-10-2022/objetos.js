var jose = {  // Se define la variable jose
    nombre: 'Jose', 
    apellido: 'Gutierrez',
    edad: 16
}

var jafet = {  // Se define la variable jafet
    nombre: 'Jafet',
    apellido: 'Vega',
    edad: 17
}

function imprimirNombreEnMayusculas(persona){
    var nombre = persona.nombre.toUpperCase();
    console.log(nombre);
}

imprimirNombreEnMayusculas(jose);
imprimirNombreEnMayusculas(jafet);

