var nombre = 'Jose' , edad = 16;  // Variable nombre y edad

function imprimirNombreEnMayusculas(n){  // Esta es una funcion imprime el nombre en mayusculas
    n = n.toUpperCase();
    console.log(n);
    
    
}

imprimirNombreEnMayusculas(nombre);  // Aquí se imprime el nombre en mayusculas

//crear una funcion que escriba mi nombre en minusculas

function nombreEnMinusculas(n){  // Esta funcion sirve para que se escriba el nombre en minusculas
    n = n.toLowerCase();
    console.log(n);
    
    
}

nombreEnMinusculas(nombre);