var nombre = 'Jose' , edad = 16; // Define el la variable Jose, tambien la variable Edad

function imprimirEdad(n, e){  // Esta funcion sirve para imprimir un resultado en la consola 
    console.log(`${n} tiene ${e} años`);

}

//ejecutando funcion
imprimirEdad(nombre , edad);
imprimirEdad('Jafet' , 15);
imprimirEdad('Juan' , 18);

imprimirEdad('Pedro' , 24);
imprimirEdad('Pablo', 27);