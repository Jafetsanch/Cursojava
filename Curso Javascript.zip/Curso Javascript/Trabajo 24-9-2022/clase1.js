var edad = '16';  // Se define la variable edad, con la cual se trabajara 
var nombre = 'Jose', apellido = 'Gutierrez';  // Variable Nombre y apellido cpn las cuales trabajaremos

console.log('Hola ' + ' ' + nombre + ' ' + apellido);  // Esto es para que la consola muestre los resultados que se le pide
console.log('Se que tienes ' + edad + ' '  + 'años');  // Aqui ocurre lo mismo que en la parte de arriba