var nombre = "Jose",  apellido = "Gutierrez";  // Aquí se definen dos variables, con las cuales se trabajara en todo el trabajo 

var nombreEnMayusculas = nombre.toUpperCase();  // Esta variable define como se debe de mostrar las variables anteriores en la consola
var apellidoEnMayusculas = apellido.toUpperCase();  // Esto basicamente es lo mismo que en la anterior variable nomas que en vez del nombre es
  // El apellido en mayusculas
var primeraLetraDelNombre = nombre.charAt(0);  // Esta variable es para solo poner la letra del primer nombre en este caso la letra J
var cantidadDeLetrasDelNombre = nombre.length;  // Aqui esta variable lo que hace es decir cuantas letras tiene el nombre

var nombreCompleto = `${nombre} ${apellido}`;  // En esta variable se realiza la operacion para mostrar todo el nombre, nombre y apellido