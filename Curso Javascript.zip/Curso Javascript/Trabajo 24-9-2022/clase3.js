var a = 5;  // Se define la variable (a) con la cual se estara trabajando en todo el programa

var b = 10;  // Se define la variable (b) con la cual se trabajara en todo el programa

var suma = a + b;    // Aquí se define una variable la cual lleva por nombre suma, esta realiza la operaacion suma
var resta = a - b;  // Aquí se define una variable la cual lleva por nombre resta, esta realiza la operacion resta
var multiplicacion = a * b; // Aquí se define una variable la cual se llama multiplicacion, esta realiza la operacion de multiplicar
var division = a / b; // Esta es la variable la cual se definio como division, y esta lo que hace es dividir

//
var precioVino = 200.3; // Es una variable de precio de un producto, y tiene una cantidad ya definida
 

var total = precioVino*100*3/100;  // Aquí se define la variable total, la cual es el resultado del precio del vino
var totalStr = total.toFixed(2);  // Se define la variable totalSt
var total2 = parseFloat(totalStr); // Define la variable total2 
console.log("el costo del vino fue de:");  // Aquí se define lo que tiene que decir la consola
console.log(total.toFixed(2))
//MOSTRAR CON DOS DECIMALES EN VARIABLE NUMERICA

//mostrar con dos decimales en variable numerica